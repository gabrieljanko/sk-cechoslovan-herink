// Vercel serverless function entry point
export { default } from '../server/index.js';