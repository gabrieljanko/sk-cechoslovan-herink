import { PlayersList } from "@/components/players/players-list";

export default function Players() {
  return (
    <PlayersList />
  );
}
